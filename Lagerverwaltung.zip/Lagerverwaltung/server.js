import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { parse } from 'csv-parse/sync';
import { stringify } from 'csv-stringify/sync';
import cors from 'cors';
import bodyParser from 'body-parser';
import multer from 'multer';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;
const DATA_DIR = path.join(__dirname, 'data');
const ARCHIVE_DIR = path.join(DATA_DIR, 'archive');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const CSV_FILE = path.join(DATA_DIR, 'lager.csv');

app.use(cors());
app.use(bodyParser.json());

// Statische Dateien ausliefern
app.use(express.static('dist'));

const COLUMNS = [
    "Datum Bestellung", "Produkt", "Hersteller Artikelnummer", "Anzahl Bestellt", 
    "Projekt oder Kunde", "Ist Projekt", "Projektname", "Bestellt von", "Lieferant", 
    "Datum Eingang", "Eingebucht von", "Anzahl Erhalten", "Seriennummern", 
    "Lieferscheinnummer", "Inventarisiert", "Ausgeliefert", "ID"
];

// Ordnerstruktur sicherstellen
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
if (!fs.existsSync(ARCHIVE_DIR)) fs.mkdirSync(ARCHIVE_DIR);
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);

// Hilfsfunktion: CSV mit BOM schreiben (f�r Excel Umlaute Support)
const writeCsvWithBOM = (filepath, data, options) => {
    const csvContent = stringify(data, options);
    // \uFEFF ist das UTF-8 BOM. Das sagt Excel: "Hier kommen Umlaute!"
    fs.writeFileSync(filepath, '\uFEFF' + csvContent, { encoding: 'utf8' });
};

// Hilfsfunktion: CSV lesen (BOM ignorieren)
const readCsvSafe = (filepath) => {
    let content = fs.readFileSync(filepath, 'utf8');
    // Falls BOM vorhanden, entfernen
    if (content.charCodeAt(0) === 0xFEFF) {
        content = content.slice(1);
    }
    return parse(content, { columns: true, skip_empty_lines: true, relax_quotes: true });
};


if (!fs.existsSync(CSV_FILE)) {
    // Leere Datei initialisieren
    writeCsvWithBOM(CSV_FILE, [], { header: true, columns: COLUMNS });
    console.log("Neue lager.csv erstellt.");
}

// --- MULTER KONFIGURATION (Uploads) ---
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const bestellnummer = req.params.id;
        const targetDir = path.join(UPLOAD_DIR, bestellnummer);
        if (!fs.existsSync(targetDir)) {
            fs.mkdirSync(targetDir, { recursive: true });
        }
        cb(null, targetDir);
    },
    filename: function (req, file, cb) {
        // Encoding Fix f�r Dateinamen mit Umlauten beim Upload
        const originalName = Buffer.from(file.originalname, 'latin1').toString('utf8');
        cb(null, originalName);
    }
});
const upload = multer({ storage: storage });


// --- API ---

app.get('/api/items', (req, res) => {
    try {
        const records = readCsvSafe(CSV_FILE);
        records.sort((a, b) => (b["Datum Bestellung"] || '').localeCompare(a["Datum Bestellung"] || ''));
        res.json(records);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Fehler beim Lesen der CSV" });
    }
});

app.post('/api/items', (req, res) => {
    try {
        const newItem = req.body;
        if (!newItem.ID) {
            newItem.ID = `BN-${Date.now()}`;
        }

        const records = readCsvSafe(CSV_FILE);
        records.push(newItem);

        writeCsvWithBOM(CSV_FILE, records, { header: true, columns: COLUMNS });
        res.json({ success: true, item: newItem });
    } catch (err) {
        res.status(500).json({ error: "Fehler beim Speichern" });
    }
});

app.put('/api/items/:id', (req, res) => {
    try {
        const id = req.params.id;
        const updatedData = req.body;
        
        let records = readCsvSafe(CSV_FILE);
        
        const index = records.findIndex(r => r.ID === id);
        if (index !== -1) {
            records[index] = { ...records[index], ...updatedData };
            writeCsvWithBOM(CSV_FILE, records, { header: true, columns: COLUMNS });
            res.json({ success: true });
        } else {
            res.status(404).json({ error: "Nicht gefunden" });
        }
    } catch (err) {
        res.status(500).json({ error: "Update Fehler" });
    }
});

app.delete('/api/items/:id', (req, res) => {
    try {
        const id = req.params.id;
        let records = readCsvSafe(CSV_FILE);
        
        const newRecords = records.filter(r => r.ID !== id);
        
        writeCsvWithBOM(CSV_FILE, newRecords, { header: true, columns: COLUMNS });

        // Optional: Auch Upload-Ordner l�schen
        const uploadDir = path.join(UPLOAD_DIR, id);
        if (fs.existsSync(uploadDir)) {
            fs.rmSync(uploadDir, { recursive: true, force: true });
        }

        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: "L�sch Fehler" });
    }
});

// --- DATEI UPLOAD API ---

app.post('/api/upload/:id', upload.array('files'), (req, res) => {
    res.json({ success: true, files: req.files });
});

app.get('/api/files/:id', (req, res) => {
    const id = req.params.id;
    const targetDir = path.join(UPLOAD_DIR, id);
    
    if (!fs.existsSync(targetDir)) {
        return res.json([]);
    }

    try {
        const files = fs.readdirSync(targetDir).map(file => {
            return {
                name: file,
                url: `/api/download/${id}/${encodeURIComponent(file)}`
            };
        });
        res.json(files);
    } catch (e) {
        res.status(500).json({ error: "Konnte Dateien nicht lesen" });
    }
});

app.get('/api/download/:id/:filename', (req, res) => {
    const { id, filename } = req.params;
    const filePath = path.join(UPLOAD_DIR, id, filename);
    
    if (filename.includes('..') || id.includes('..')) {
        return res.status(400).send('Ung�ltiger Pfad');
    }

    if (fs.existsSync(filePath)) {
        res.download(filePath);
    } else {
        res.status(404).send('Datei nicht gefunden');
    }
});

app.delete('/api/files/:id/:filename', (req, res) => {
    const { id, filename } = req.params;
    const filePath = path.join(UPLOAD_DIR, id, filename);

    if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        res.json({ success: true });
    } else {
        res.status(404).json({ error: "Datei nicht gefunden" });
    }
});


// --- ARCHIV API ---

app.post('/api/archive', (req, res) => {
    try {
        const filterMode = req.body.filterMode || 'all'; 
        let records = readCsvSafe(CSV_FILE);

        const toArchive = [];
        const toKeep = [];

        records.forEach(item => {
            const ordered = parseInt(item["Anzahl Bestellt"] || '0');
            const received = parseInt(item["Anzahl Erhalten"] || '0');
            const hasEntryDate = !!item["Datum Eingang"];

            const isCompleted = hasEntryDate && (received >= ordered) && (ordered > 0);
            
            let shouldArchive = isCompleted;

            if (filterMode === 'delivered_only') {
                shouldArchive = shouldArchive && (item["Ausgeliefert"] === 'y');
            }

            if (shouldArchive) {
                toArchive.push(item);
            } else {
                toKeep.push(item);
            }
        });

        if (toArchive.length > 0) {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const suffix = filterMode === 'delivered_only' ? '_delivered' : '';
            const archiveFilename = `archiv${suffix}_${timestamp}.csv`;
            const archivePath = path.join(ARCHIVE_DIR, archiveFilename);
            
            writeCsvWithBOM(archivePath, toArchive, { header: true, columns: COLUMNS });
            writeCsvWithBOM(CSV_FILE, toKeep, { header: true, columns: COLUMNS });
        }

        res.json({ success: true, archivedCount: toArchive.length });
    } catch (err) {
        console.error("Archivierungsfehler:", err);
        res.status(500).json({ error: "Fehler bei der Archivierung" });
    }
});

app.get('/api/archives', (req, res) => {
    try {
        const files = fs.readdirSync(ARCHIVE_DIR).filter(file => file.endsWith('.csv'));
        const fileDetails = files.map(file => {
            const stats = fs.statSync(path.join(ARCHIVE_DIR, file));
            return {
                name: file,
                created: stats.birthtime,
                size: (stats.size / 1024).toFixed(1) + ' KB'
            };
        }).sort((a, b) => b.created - a.created);

        res.json(fileDetails);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Konnte Archiv nicht lesen" });
    }
});

app.get('/api/archives/search', (req, res) => {
    const q = req.query.q ? req.query.q.toLowerCase() : '';
    if (!q) return res.json([]);

    try {
        if (!fs.existsSync(ARCHIVE_DIR)) {
            return res.json([]);
        }

        const files = fs.readdirSync(ARCHIVE_DIR).filter(file => file.endsWith('.csv'));
        let allMatches = [];

        files.forEach(file => {
            try {
                const filePath = path.join(ARCHIVE_DIR, file);
                // Safe Read auch hier
                let content = fs.readFileSync(filePath, 'utf8');
                if (content.charCodeAt(0) === 0xFEFF) content = content.slice(1);

                if (!content || content.trim().length === 0) return;

                const records = parse(content, { 
                    columns: true, skip_empty_lines: true, relax_quotes: true, relax_column_count: true 
                });

                const matches = records.filter(item => {
                    const fullText = Object.values(item).join(' ').toLowerCase();
                    return fullText.includes(q);
                });

                matches.forEach(m => {
                    m._isArchived = true;
                    m._sourceFile = file;
                });

                allMatches = [...allMatches, ...matches];
            } catch (innerErr) {
                console.error(`Fehler bei Datei ${file}:`, innerErr.message);
            }
        });

        allMatches.sort((a, b) => (b["Datum Bestellung"] || '').localeCompare(a["Datum Bestellung"] || ''));
        res.json(allMatches);
    } catch (err) {
        res.status(500).json({ error: "Suche fehlgeschlagen" });
    }
});

app.get('/api/archives/:filename', (req, res) => {
    const filename = req.params.filename;
    if (!filename.match(/^[a-z0-9_\-\.]+$/i)) return res.status(400).send("Ung�ltig");
    
    const filepath = path.join(ARCHIVE_DIR, filename);
    if (fs.existsSync(filepath)) {
        res.download(filepath);
    } else {
        res.status(404).send("Datei nicht gefunden");
    }
});

app.listen(PORT, () => console.log(`Server l�uft auf Port ${PORT}`));