import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
    Plus, Download, Upload, Search, Package, CheckCircle2, 
    Clock, Edit3, Save, X, ChevronRight, Filter, Trash2, Loader2, 
    RefreshCw, PieChart, AlertTriangle, Eye, FileSpreadsheet, CheckSquare, 
    Square, Folder, FolderOpen, Archive, FolderClock, FileText, ArrowLeft, SearchX, Truck, Box, Paperclip
} from 'lucide-react';

// --- Hilfsfunktion: CSV Parsing Client-Side ---
const parseCSVClient = (text) => {
    const rows = text.split('\n').filter(row => row.trim() !== '');
    if (rows.length < 2) return [];
    const headers = rows[0].split(',').map(h => h.trim());
    return rows.slice(1).map(row => {
        const values = [];
        let currentVal = '';
        let insideQuotes = false;
        for (let i = 0; i < row.length; i++) {
            const char = row[i];
            if (char === '"') insideQuotes = !insideQuotes;
            else if (char === ',' && !insideQuotes) { values.push(currentVal.trim()); currentVal = ''; }
            else currentVal += char;
        }
        values.push(currentVal.trim());
        const obj = {};
        headers.forEach((header, i) => {
            let val = values[i] || '';
            if (val.startsWith('"') && val.endsWith('"')) val = val.slice(1, -1);
            obj[header] = val;
        });
        return obj;
    });
};

// --- Hilfsfunktion: CSV Export ---
const convertToCSV = (objArray) => {
    const array = typeof objArray !== 'object' ? JSON.parse(objArray) : objArray;
    if (array.length === 0) return '';
    
    const keys = [
        "Datum Bestellung", "Produkt", "Hersteller Artikelnummer", "Anzahl Bestellt", 
        "Projekt oder Kunde", "Ist Projekt", "Projektname", "Bestellt von", "Lieferant", 
        "Datum Eingang", "Eingebucht von", "Anzahl Erhalten", "Seriennummern", 
        "Lieferscheinnummer", "Inventarisiert", "Ausgeliefert", "ID"
    ];
    const displayHeaders = keys.map(k => k === "Projekt oder Kunde" ? "Kunde" : k);

    let str = displayHeaders.join(',') + '\r\n';

    for (let i = 0; i < array.length; i++) {
        let line = '';
        for (let index in keys) {
            if (line !== '') line += ',';
            let key = keys[index];
            let val = array[i][key] || '';
            if (val.toString().includes(',') || val.toString().includes('"') || val.toString().includes('\n')) {
                val = `"${val.toString().replace(/"/g, '""')}"`;
            }
            line += val;
        }
        str += line + '\r\n';
    }
    return str;
};

export default function App() {
    // --- State ---
    const [items, setItems] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    
    // Archive States
    const [isArchiveListOpen, setIsArchiveListOpen] = useState(false);
    const [archiveFiles, setArchiveFiles] = useState([]);
    const [archiveSearchTerm, setArchiveSearchTerm] = useState('');
    const [archiveSearchResults, setArchiveSearchResults] = useState(null); 
    const [searchingArchive, setSearchingArchive] = useState(false);
    const [isArchiveOptionsOpen, setIsArchiveOptionsOpen] = useState(false);

    const [editingItem, setEditingItem] = useState(null);
    const [viewingItem, setViewingItem] = useState(null);
    const [filterStatus, setFilterStatus] = useState('all'); 
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    
    // Formular States
    const [isProjectSelected, setIsProjectSelected] = useState(false);
    const [currentOrderQty, setCurrentOrderQty] = useState(0);
    const [currentReceiveQty, setCurrentReceiveQty] = useState(0);

    // Upload / File States
    const [existingFiles, setExistingFiles] = useState([]); 
    const [filesToDelete, setFilesToDelete] = useState([]); 
    const [newFilesToUpload, setNewFilesToUpload] = useState([]); 
    const [viewingFiles, setViewingFiles] = useState([]); 
    
    const fileInputRef = useRef(null);
    const docInputRef = useRef(null);

    // --- API Calls ---
    const loadItems = async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/items');
            if(res.ok) {
                const data = await res.json();
                setItems(data);
            }
        } catch (e) {
            console.error("Ladefehler:", e);
        } finally {
            setLoading(false);
        }
    };

    const loadArchives = async () => {
        try {
            const res = await fetch('/api/archives');
            if(res.ok) {
                const data = await res.json();
                setArchiveFiles(data);
            }
        } catch (e) {
            console.error("Archiv-Ladefehler:", e);
        }
    };

    const loadAttachedFiles = async (itemId) => {
        if (!itemId) {
            setExistingFiles([]);
            return;
        }
        try {
            const res = await fetch(`/api/files/${itemId}`);
            if (res.ok) {
                const files = await res.json();
                setExistingFiles(files);
            } else {
                setExistingFiles([]);
            }
        } catch (e) {
            console.error(e);
            setExistingFiles([]);
        }
    };

    useEffect(() => {
        const fetchViewFiles = async () => {
            if (viewingItem && viewingItem.ID) {
                try {
                    const res = await fetch(`/api/files/${viewingItem.ID}`);
                    if (res.ok) {
                        const files = await res.json();
                        setViewingFiles(files);
                    } else {
                        setViewingFiles([]);
                    }
                } catch (e) {
                    setViewingFiles([]);
                }
            } else {
                setViewingFiles([]);
            }
        };
        fetchViewFiles();
    }, [viewingItem]);

    const searchInArchives = async () => {
        if(!archiveSearchTerm.trim()) {
            setArchiveSearchResults(null);
            return;
        }
        setSearchingArchive(true);
        try {
            const res = await fetch(`/api/archives/search?q=${encodeURIComponent(archiveSearchTerm)}`);
            if(res.ok) {
                const data = await res.json();
                setArchiveSearchResults(data);
            } else {
                const status = res.status;
                console.error("Archiv Suche Fehler Status:", status);
                alert(`Fehler bei der Suche (Status ${status}).`);
            }
        } catch(e) {
            console.error(e);
            alert("Verbindungsfehler bei der Suche. Ist der Server an?");
        } finally {
            setSearchingArchive(false);
        }
    };

    useEffect(() => {
        loadItems();
        const interval = setInterval(loadItems, 60000); 
        return () => clearInterval(interval);
    }, []);

    const handleOpenModal = (item) => {
        setEditingItem(item);
        setIsProjectSelected(item ? item["Ist Projekt"] === 'y' : false);
        setCurrentOrderQty(item ? parseInt(item["Anzahl Bestellt"] || 0) : 0);
        setCurrentReceiveQty(item ? parseInt(item["Anzahl Erhalten"] || 0) : 0);
        
        // Reset File States
        setFilesToDelete([]);
        setNewFilesToUpload([]);

        if (item && item.ID) {
            loadAttachedFiles(item.ID);
        } else {
            setExistingFiles([]);
        }
        
        setIsModalOpen(true);
    };

    const handleOpenArchiveList = () => {
        loadArchives();
        setArchiveSearchTerm('');
        setArchiveSearchResults(null);
        setIsArchiveListOpen(true);
    };

    const saveItem = async (formData) => {
        setSubmitting(true);
        try {
            const method = (editingItem && editingItem.ID) ? 'PUT' : 'POST';
            const url = (editingItem && editingItem.ID) 
                ? `/api/items/${editingItem.ID}` 
                : '/api/items';

            if(editingItem && editingItem.ID) formData.ID = editingItem.ID;

            // 1. Item speichern
            const res = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            if(res.ok) {
                const savedItem = await res.json(); 
                const targetId = (editingItem && editingItem.ID) ? editingItem.ID : savedItem.ID;

                // 2. L schungen ausf hren (Parallel)
                if (filesToDelete.length > 0 && targetId) {
                    await Promise.all(filesToDelete.map(filename => 
                        fetch(`/api/files/${targetId}/${encodeURIComponent(filename)}`, { method: 'DELETE' })
                    ));
                }

                // 3. Uploads ausf hren
                if (newFilesToUpload.length > 0 && targetId) {
                    const uploadData = new FormData();
                    for (let i = 0; i < newFilesToUpload.length; i++) {
                        uploadData.append('files', newFilesToUpload[i]);
                    }
                    await fetch(`/api/upload/${targetId}`, {
                        method: 'POST',
                        body: uploadData
                    });
                }

                await loadItems();
                setIsModalOpen(false);
                setEditingItem(null);
            } else {
                alert("Fehler beim Speichern der Daten.");
            }
        } catch (e) {
            alert("Netzwerkfehler: " + e.message);
        } finally {
            setSubmitting(false);
        }
    };

    const deleteItem = async (id) => {
        // \u00F6 =  
        if (window.confirm("Eintrag wirklich l\u00F6schen?")) {
            try {
                await fetch(`/api/items/${id}`, { method: 'DELETE' });
                await loadItems();
                if (viewingItem && viewingItem.ID === id) setViewingItem(null);
            } catch (e) {
                alert("Konnte nicht l\u00F6schen");
            }
        }
    };

    const performArchive = async (filterMode) => {
        setIsArchiveOptionsOpen(false); 
        setLoading(true);
        try {
            const res = await fetch('/api/archive', { 
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ filterMode }) 
            });
            const data = await res.json();
            if(data.success) {
                // \u00E4 =  
                alert(`${data.archivedCount} Eintr\u00E4ge erfolgreich archiviert.`);
                await loadItems();
            } else {
                alert("Fehler beim Archivieren.");
            }
        } catch (e) {
            alert("Netzwerkfehler beim Archivieren.");
        } finally {
            setLoading(false);
        }
    };

    const handleClientImport = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        // \u00F6 =  
        if(!confirm("M\u00F6chtest du diese Daten in die Datenbank importieren?")) return;

        setLoading(true);
        const reader = new FileReader();
        reader.onload = async (event) => {
            const parsed = parseCSVClient(event.target.result);
            for (const item of parsed) {
                await fetch('/api/items', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(item)
                });
            }
            await loadItems();
            // \u00E4 =  
            alert(`${parsed.length} Eintr\u00E4ge importiert!`);
        };
        reader.readAsText(file);
        e.target.value = null;
    };

    const handleFileSelect = (e) => {
        const files = Array.from(e.target.files);
        if (files.length > 0) {
            setNewFilesToUpload(prev => [...prev, ...files]);
        }
        if(docInputRef.current) docInputRef.current.value = '';
    };

    const markFileForDeletion = (filename, isNewFile = false) => {
        if (isNewFile) {
            setNewFilesToUpload(prev => prev.filter(f => f.name !== filename));
        } else {
            setFilesToDelete(prev => [...prev, filename]);
        }
    };

    const getItemStatus = (item) => {
        const ordered = parseInt(item["Anzahl Bestellt"]) || 0;
        const received = parseInt(item["Anzahl Erhalten"]) || 0;
        const hasEntryDate = !!item["Datum Eingang"];

        if (hasEntryDate && received >= ordered && ordered > 0) return 'completed';
        if (received > 0 && received < ordered) return 'partial';
        
        const orderDate = new Date(item["Datum Bestellung"]);
        const diffDays = Math.ceil(Math.abs(new Date() - orderDate) / (1000 * 60 * 60 * 24));
        if (diffDays > 30) return 'warning';

        return 'open';
    };

    const filteredItems = useMemo(() => {
        const filtered = items.filter(item => {
            const status = getItemStatus(item);
            let fullSearchString = Object.values(item).join(' ').toLowerCase();
            
            // Umlaute hier auch escaped f r Suche
            // \u00E4 =  , \u00DC =  
            if (status === 'completed') fullSearchString += ' fertig komplett geliefert';
            if (status === 'partial') fullSearchString += ' teillieferung teil';
            if (status === 'open') fullSearchString += ' offen zulauf';
            if (status === 'warning') fullSearchString += ' \u00DCberf\u00E4llig versp\u00E4tet';
            if (item["Ist Projekt"] === 'y') fullSearchString += ' projekt';
            if (item["Ausgeliefert"] === 'y') fullSearchString += ' ausgeliefert';
            if (item.ID) fullSearchString += ' ' + item.ID.toLowerCase();

            const matchesSearch = fullSearchString.includes(searchTerm.toLowerCase());
            
            const matchesFilter = 
                filterStatus === 'all' || 
                (filterStatus === 'open' && (status === 'open' || status === 'partial' || status === 'warning')) || 
                (filterStatus === 'completed' && status === 'completed') ||
                (filterStatus === 'warning' && status === 'warning') ||
                (filterStatus === 'partial' && status === 'partial');

            return matchesSearch && matchesFilter;
        });

        return filtered.sort((a, b) => {
            const dateA = a["Datum Bestellung"] || '';
            const dateB = b["Datum Bestellung"] || '';
            const dateComparison = dateB.localeCompare(dateA);
            if (dateComparison === 0) {
                return (b.ID || '').localeCompare(a.ID || '');
            }
            return dateComparison;
        });
    }, [items, searchTerm, filterStatus]);

    const handleExport = () => {
        const csvData = convertToCSV(filteredItems);
        const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", `Lager_Export_${new Date().toISOString().slice(0,10)}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const visibleFilesList = [
        ...existingFiles.filter(f => !filesToDelete.includes(f.name)).map(f => ({ ...f, isNew: false })),
        ...newFilesToUpload.map(f => ({ name: f.name, url: '#', isNew: true }))
    ];

    return (
        <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
        {/* Header */}
        <header className="bg-white border-b sticky top-0 z-10 shadow-sm">
            <div className="max-w-[1600px] mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-3">
                <img src="/favicon.ico" alt="Logo" className="w-10 h-10 object-contain rounded-lg" />
                <div>
                    {/* MOBILE OPTIMIZED: Titel auf Mobile verstecken */}
                    <h1 className="text-xl font-bold tracking-tight hidden md:block">Lager-Manager</h1>
                    {/* MOBILE OPTIMIZED: Badge auf Mobile verstecken */}
                    <div className="text-[10px] text-green-600 font-bold uppercase tracking-wider items-center gap-1 hidden md:flex">
                        <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div> Live CSV
                    </div>
                </div>
            </div>
            
            <div className="flex items-center gap-2 sm:gap-3">
                <button onClick={handleOpenArchiveList} className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-md transition-colors" title="Vorhandene Archive anzeigen">
                    <FolderClock size={18} /> <span className="hidden sm:inline">Archive</span>
                </button>
                {/* FIX: Tooltip mit JS Expression Syntax f r Umlaute - MOBILE HIDDEN */}
                <button onClick={() => setIsArchiveOptionsOpen(true)} className="hidden md:flex items-center gap-2 px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-md transition-colors" title={"Abgeschlossene Eintr\u00E4ge werden archiviert"}>
                    <Archive size={18} /> <span className="hidden sm:inline">Aufr{'\u00E4'}umen</span>
                </button>

                <div className="h-6 w-px bg-slate-200 mx-1 hidden sm:block"></div>

                {/* MOBILE HIDDEN */}
                <button onClick={handleExport} className="hidden md:flex items-center gap-2 px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-md transition-colors">
                    <FileSpreadsheet size={18} /> <span className="hidden sm:inline">Export</span>
                </button>
                {/* MOBILE HIDDEN */}
                <button onClick={() => fileInputRef.current?.click()} className="hidden md:flex items-center gap-2 px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-md transition-colors">
                    <Upload size={18} /> <span className="hidden sm:inline">Import</span>
                </button>
                <input type="file" ref={fileInputRef} onChange={handleClientImport} accept=".csv" className="hidden" />
                <button onClick={loadItems} className="p-2 text-slate-500 hover:bg-slate-100 rounded-md transition-all">
                    <RefreshCw size={18} className={loading ? "animate-spin" : ""} />
                </button>
                {/* MOBILE OPTIMIZED: Text auf Mobile verstecken (nur Plus-Icon) */}
                <button onClick={() => handleOpenModal(null)} className="flex items-center gap-2 px-3 sm:px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-all shadow-md shadow-blue-100">
                    <Plus size={18} /> <span className="hidden sm:inline">Neu bestellen</span>
                </button>
            </div>
            </div>
        </header>

        <main className="max-w-[1600px] mx-auto p-2 sm:p-4 md:p-6">
            {/* Stats & Filters - MOBILE OPTIMIZED: Grid 2-spaltig auf Mobile */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 mb-4 md:mb-6">
                <button onClick={() => setFilterStatus('all')} className={`p-3 md:p-4 rounded-xl border shadow-sm text-left transition-all ${filterStatus === 'all' ? 'bg-blue-50 border-blue-200' : 'bg-white hover:bg-slate-50'}`}>
                    {/* LABELS WIEDERHERGESTELLT */}
                    <p className="text-xs md:text-sm text-slate-500 mb-1">Alle Eintr{'\u00E4'}ge</p>
                    <p className="text-xl md:text-2xl font-bold text-slate-700">{items.length}</p>
                </button>
                <button onClick={() => setFilterStatus('open')} className={`p-3 md:p-4 rounded-xl border shadow-sm flex flex-col justify-between text-left transition-all ${filterStatus === 'open' ? 'bg-orange-50 border-orange-200' : 'bg-white hover:bg-slate-50'}`}>
                    <div className="flex justify-between w-full">
                        <div>
                            {/* LABELS WIEDERHERGESTELLT */}
                            <p className="text-xs md:text-sm text-orange-600 mb-1 font-medium">Offen / Zulauf</p>
                            <p className="text-xl md:text-2xl font-bold text-slate-700">{items.filter(i => getItemStatus(i) === 'open' || getItemStatus(i) === 'warning').length}</p>
                        </div>
                        <Clock className="text-orange-200 w-6 h-6 md:w-8 md:h-8" />
                    </div>
                </button>
                    <button onClick={() => setFilterStatus('partial')} className={`p-3 md:p-4 rounded-xl border shadow-sm flex flex-col justify-between text-left transition-all ${filterStatus === 'partial' ? 'bg-blue-50 border-blue-300 ring-1 ring-blue-300' : 'bg-white hover:bg-slate-50'}`}>
                    <div className="flex justify-between w-full">
                        <div>
                            {/* LABELS WIEDERHERGESTELLT */}
                            <p className="text-xs md:text-sm text-blue-600 mb-1 font-medium">Teillieferung</p>
                            <p className="text-xl md:text-2xl font-bold text-slate-700">{items.filter(i => getItemStatus(i) === 'partial').length}</p>
                        </div>
                        <PieChart className="text-blue-200 w-6 h-6 md:w-8 md:h-8" />
                    </div>
                </button>
                <button onClick={() => setFilterStatus('completed')} className={`p-3 md:p-4 rounded-xl border shadow-sm flex flex-col justify-between text-left transition-all ${filterStatus === 'completed' ? 'bg-emerald-50 border-emerald-200' : 'bg-white hover:bg-slate-50'}`}>
                    <div className="flex justify-between w-full">
                        <div>
                            {/* LABELS WIEDERHERGESTELLT */}
                            <p className="text-xs md:text-sm text-emerald-600 mb-1 font-medium">Abgeschlossen</p>
                            <p className="text-xl md:text-2xl font-bold text-slate-700">{items.filter(i => getItemStatus(i) === 'completed').length}</p>
                        </div>
                        <CheckCircle2 className="text-emerald-200 w-6 h-6 md:w-8 md:h-8" />
                    </div>
                </button>
            </div>

            {/* Toolbar */}
            <div className="flex flex-col md:flex-row gap-4 mb-4 items-center">
            <div className="relative flex-1 w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input type="text" placeholder="Suche (Produkt, Kunde, Status, Projektname...)" className="w-full pl-10 pr-4 py-2 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all shadow-sm" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
            </div>
            </div>

            {/* Data Table - MOBILE OPTIMIZED: Padding angepasst */}
            <div className="bg-white rounded-xl border shadow-sm overflow-hidden min-h-[400px]">
            <div className="overflow-x-auto">
                <table className="w-full text-left text-sm border-collapse">
                <thead>
                    <tr className="bg-slate-50 border-b text-slate-600 font-medium">
                    <th className="px-2 py-3 sm:px-4 min-w-[140px]">Status</th>
                    <th className="px-2 py-3 sm:px-4 min-w-[120px]">Bestelldatum</th>
                    <th className="px-2 py-3 sm:px-4 min-w-[250px]">Produkt / Artikelnummer</th>
                    <th className="px-2 py-3 sm:px-4 min-w-[150px]">Kunde</th>
                    <th className="px-2 py-3 sm:px-4 min-w-[120px]">Menge</th>
                    <th className="px-2 py-3 sm:px-4 min-w-[120px]">Eingang</th>
                    <th className="px-2 py-3 sm:px-4 min-w-[150px]">Projektname</th> 
                    <th className="px-2 py-3 sm:px-4 text-right sticky right-0 bg-slate-50">Aktion</th>
                    </tr>
                </thead>
                <tbody className="divide-y">
                    {loading ? (
                        <tr><td colSpan="8" className="p-8 text-center text-slate-400"><Loader2 className="animate-spin mx-auto mb-2"/>Lade Daten aus CSV...</td></tr>
                    ) : filteredItems.length === 0 ? (
                    <tr><td colSpan="8" className="px-4 py-12 text-center text-slate-400">Keine Eintr{'\u00E4'}ge gefunden.</td></tr>
                    ) : (
                    filteredItems.map((item) => {
                        const status = getItemStatus(item);
                        const ordered = item["Anzahl Bestellt"];
                        const received = item["Anzahl Erhalten"];
                        const isProject = item["Ist Projekt"] === 'y';
                        const isDelivered = item["Ausgeliefert"] === 'y';

                        return (
                        <tr key={item.ID || Math.random()} className="hover:bg-blue-50 cursor-pointer transition-colors group" onClick={() => setViewingItem(item)}>
                            <td className="px-2 py-3 sm:px-4">
                                {status === 'completed' && <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800 border border-emerald-200"><CheckCircle2 size={12} /> Komplett</span>}
                                {status === 'partial' && <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 border border-blue-200"><PieChart size={12} /> Teillieferung</span>}
                                {status === 'open' && <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800 border border-orange-200"><Clock size={12} /> Offen</span>}
                                {/* \u00DC =  , \u00E4 =   */}
                                {status === 'warning' && <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 border border-red-200"><AlertTriangle size={12} /> {'\u00DC'}berf{'\u00E4'}llig</span>}
                            </td>
                            <td className="px-2 py-3 sm:px-4 text-slate-600 text-sm">
                                <div className="font-mono text-xs text-slate-400 mb-0.5">{item.ID}</div>
                                {item["Datum Bestellung"]}
                            </td>
                            <td className="px-2 py-3 sm:px-4">
                                <div className="font-semibold text-slate-900">{item["Produkt"]}</div>
                                <div className="text-xs text-slate-400 font-mono">{item["Hersteller Artikelnummer"] || '-'}</div>
                            </td>
                            <td className="px-2 py-3 sm:px-4 font-medium text-slate-700">
                                <div className="flex items-center gap-2">
                                    {item["Projekt oder Kunde"]}
                                    {isProject && <Folder size={14} className="text-blue-500" title="Projekt" />}
                                </div>
                            </td>
                            <td className="px-2 py-3 sm:px-4">
                                <div className="flex flex-col">
                                    <span className="font-medium text-slate-900">{ordered} Bestellt</span>
                                    {received && received !== '0' ? <span className={`text-xs font-bold ${status === 'partial' ? 'text-blue-600' : 'text-emerald-600'}`}>{received} Erhalten</span> : <span className="text-xs text-slate-400">0 Erhalten</span>}
                                </div>
                            </td>
                            <td className="px-2 py-3 sm:px-4 text-slate-600 text-sm">
                                <div className="flex items-center justify-between">
                                    <span>{item["Datum Eingang"] || '-'}</span>
                                    {isDelivered && <Truck size={16} className="text-blue-500" title="An Kunden ausgeliefert"/>}
                                </div>
                            </td>
                            <td className="px-2 py-3 sm:px-4 text-sm text-slate-600">
                                {item["Projektname"] ? (
                                    <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded bg-slate-100 text-slate-600 border border-slate-200 text-xs font-medium">
                                        <FolderOpen size={10} /> {item["Projektname"]}
                                    </span>
                                ) : '-'}
                            </td>
                            <td className="px-2 py-3 sm:px-4 text-right sticky right-0 bg-white group-hover:bg-blue-50" onClick={(e) => e.stopPropagation()}>
                                <div className="flex justify-end gap-1 opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button onClick={(e) => { e.stopPropagation(); handleOpenModal(item); }} className="p-1.5 text-blue-600 hover:bg-blue-100 rounded-md transition-colors" title="Bearbeiten"><Edit3 size={16} /></button>
                                    {/* FIX: Tooltip als JS Expression f r Umlaute */}
                                    <button onClick={(e) => { e.stopPropagation(); deleteItem(item.ID); }} className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors" title={"L\u00F6schen"}><Trash2 size={16} /></button>
                                </div>
                            </td>
                        </tr>
                        );
                    })
                    )}
                </tbody>
                </table>
            </div>
            </div>
        </main>

        {/* ARCHIVE SELECTION MODAL */}
        {isArchiveOptionsOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
                <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl p-6 animate-in fade-in zoom-in duration-200">
                    <div className="flex items-center justify-between mb-4">
                        {/* \u00E4 =   */}
                        <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                            <Archive size={20} className="text-slate-500"/> Aufr{'\u00E4'}umen
                        </h3>
                        <button onClick={() => setIsArchiveOptionsOpen(false)} className="p-1 text-slate-400 hover:bg-slate-100 rounded-full">
                            <X size={20} />
                        </button>
                    </div>
                    {/* \u00E4 =  , \u00E4 =   */}
                    <p className="text-sm text-slate-500 mb-6">W{'\u00E4'}hlen Sie aus, welche abgeschlossenen Eintr{'\u00E4'}ge ins Archiv verschoben werden sollen.</p>
                    
                    <div className="space-y-3">
                        <button onClick={() => performArchive('all')} className="w-full flex items-center gap-3 p-4 border rounded-xl hover:bg-slate-50 hover:border-blue-300 transition-all text-left group">
                            <div className="bg-slate-100 p-2 rounded-lg group-hover:bg-blue-100 text-slate-600 group-hover:text-blue-600 transition-colors">
                                <Box size={20} />
                            </div>
                            <div>
                                <span className="block font-semibold text-slate-700">Alle abgeschlossenen</span>
                                {/* \u00E4 =   */}
                                <span className="text-xs text-slate-500">Archiviert alles, was vollst{'\u00E4'}ndig eingebucht ist.</span>
                            </div>
                        </button>

                        <button onClick={() => performArchive('delivered_only')} className="w-full flex items-center gap-3 p-4 border rounded-xl hover:bg-slate-50 hover:border-emerald-300 transition-all text-left group">
                            <div className="bg-slate-100 p-2 rounded-lg group-hover:bg-emerald-100 text-slate-600 group-hover:text-emerald-600 transition-colors">
                                <Truck size={20} />
                            </div>
                            <div>
                                <span className="block font-semibold text-slate-700">Nur ausgelieferte</span>
                                <span className="text-xs text-slate-500">Archiviert nur, was fertig UND "Ausgeliefert" ist.</span>
                            </div>
                        </button>
                    </div>

                    <div className="mt-6 flex justify-end">
                        <button onClick={() => setIsArchiveOptionsOpen(false)} className="px-4 py-2 text-sm font-medium text-slate-500 hover:text-slate-700">Abbrechen</button>
                    </div>
                </div>
            </div>
        )}

        {/* Archive List Modal (RESTRUCTURED HEADER FOR MOBILE) */}
        {isArchiveListOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
                <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200 flex flex-col h-[80vh]">
                    
                    {/* Header: Responsive Layout (Stack on mobile, Row on desktop) */}
                    <div className="p-4 border-b bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        
                        {/* Title Row (Mobile: Title + Close; Desktop: Title) */}
                        <div className="flex items-center justify-between sm:justify-start w-full sm:w-auto">
                            <h3 className="font-bold text-lg flex items-center gap-2">
                                <FolderClock size={20} className="text-slate-500"/> 
                                Archiv Verlauf
                            </h3>
                            {/* Mobile Close Button */}
                            <button onClick={() => setIsArchiveListOpen(false)} className="sm:hidden p-2 hover:bg-slate-200 rounded-full" title={"Schlie\u00DFen"}>
                                <X size={20}/>
                            </button>
                        </div>
                        
                        {/* Search Area */}
                        <div className="flex items-center gap-2 w-full sm:max-w-md">
                            <div className="flex items-center gap-2 bg-white border rounded-lg px-2 py-1 shadow-sm flex-1">
                                <Search size={16} className="text-slate-400 shrink-0"/>
                                <input 
                                    type="text" 
                                    placeholder="Schlagwort suchen..." 
                                    className="flex-1 outline-none text-sm py-1 min-w-0"
                                    value={archiveSearchTerm}
                                    onChange={(e) => setArchiveSearchTerm(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && searchInArchives()}
                                />
                                {archiveSearchTerm && (
                                    <button onClick={() => { setArchiveSearchTerm(''); setArchiveSearchResults(null); }} className="text-slate-400 hover:text-slate-600 shrink-0">
                                        <X size={14}/>
                                    </button>
                                )}
                            </div>
                            <button onClick={searchInArchives} className="px-3 py-1.5 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 flex items-center gap-1 shrink-0">
                                {searchingArchive ? <Loader2 size={14} className="animate-spin"/> : <Search size={14}/>} <span className="hidden sm:inline">Durchsuchen</span><span className="sm:hidden">Suchen</span>
                            </button>
                        </div>

                        {/* Desktop Close Button */}
                        <button onClick={() => setIsArchiveListOpen(false)} className="hidden sm:block p-2 hover:bg-slate-200 rounded-full" title={"Schlie\u00DFen"}>
                            <X size={20}/>
                        </button>
                    </div>

                    <div className="flex-1 overflow-hidden flex flex-col bg-slate-50/50 relative">
                        {searchingArchive && (
                            <div className="absolute inset-0 bg-white/50 backdrop-blur-sm z-10 flex items-center justify-center">
                                <div className="bg-white p-4 rounded-xl shadow-lg border flex items-center gap-3">
                                    <Loader2 className="animate-spin text-blue-600" size={24} />
                                    <span className="text-slate-700 font-medium">Durchsuche Archive...</span>
                                </div>
                            </div>
                        )}

                        {archiveSearchResults ? (
                            <div className="flex-1 overflow-y-auto flex flex-col">
                                <div className="p-3 bg-blue-50 border-b border-blue-100 flex items-center justify-between">
                                    <span className="text-sm font-bold text-blue-800 flex items-center gap-2"><Search size={14}/> Suchergebnisse ({archiveSearchResults.length})</span>
                                    {/* \u00FC =   */}
                                    <button onClick={() => { setArchiveSearchResults(null); setArchiveSearchTerm(''); }} className="text-xs text-blue-600 hover:underline flex items-center gap-1"><ArrowLeft size={12}/> Zur{'\u00FC'}ck zur Liste</button>
                                </div>
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left text-sm border-collapse bg-white">
                                        <thead>
                                            <tr className="bg-slate-50 border-b text-slate-600 font-medium">
                                                <th className="px-4 py-2">Status</th>
                                                <th className="px-4 py-2">Datum</th>
                                                <th className="px-4 py-2">Produkt</th>
                                                <th className="px-4 py-2">Kunde</th>
                                                <th className="px-4 py-2">Archiv-Datei</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y">
                                            {archiveSearchResults.length === 0 ? (
                                                <tr>
                                                    <td colSpan="5" className="p-12 text-center text-slate-400">
                                                        <div className="flex flex-col items-center justify-center gap-2">
                                                            <SearchX size={48} className="text-slate-300 mb-2"/>
                                                            <span className="font-medium">Keine Treffer gefunden.</span>
                                                            <span className="text-xs">Versuche es mit einem anderen Begriff.</span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ) : (
                                                archiveSearchResults.map((item, i) => (
                                                    <tr key={i} className="hover:bg-blue-50 cursor-pointer transition-colors" onClick={() => setViewingItem(item)}>
                                                        <td className="px-4 py-2">
                                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600 border border-slate-200">Archiviert</span>
                                                        </td>
                                                        <td className="px-4 py-2 text-slate-600 text-sm">{item["Datum Bestellung"]}</td>
                                                        <td className="px-4 py-2 font-medium">{item["Produkt"]}</td>
                                                        <td className="px-4 py-2">{item["Projekt oder Kunde"]}</td>
                                                        <td className="px-4 py-2 text-xs text-slate-400 font-mono">{item._sourceFile}</td>
                                                    </tr>
                                                ))
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        ) : (
                            <div className="p-0 overflow-y-auto flex-1">
                                {archiveFiles.length === 0 ? (
                                    <div className="p-8 text-center text-slate-500">
                                        <FolderOpen size={40} className="mx-auto mb-2 opacity-20"/>
                                        <p>Keine Archive gefunden.</p>
                                    </div>
                                ) : (
                                    <ul className="divide-y divide-slate-100 bg-white">
                                        {archiveFiles.map((file, idx) => (
                                            <li key={idx} className="p-4 hover:bg-slate-50 flex items-center justify-between group">
                                                <div className="flex items-center gap-3">
                                                    <div className="bg-orange-100 p-2 rounded-lg text-orange-600">
                                                        <FileText size={18} />
                                                    </div>
                                                    <div>
                                                        <p className="font-medium text-sm text-slate-700">{file.name}</p>
                                                        <p className="text-xs text-slate-400">
                                                            {new Date(file.created).toLocaleDateString()} um {new Date(file.created).toLocaleTimeString()} {'\u2022'} {file.size}
                                                        </p>
                                                    </div>
                                                </div>
                                                <a 
                                                    href={`/api/archives/${file.name}`} 
                                                    download 
                                                    className="p-2 text-blue-600 bg-blue-50 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-blue-100"
                                                    title="Herunterladen"
                                                >
                                                    <Download size={16} />
                                                </a>
                                            </li>
                                        ))}
                                    </ul>
                                )}
                            </div>
                        )}
                    </div>
                    
                    <div className="p-4 bg-slate-50 border-t flex justify-end">
                        {/* FIX: Tooltip als JS Expression f r Umlaute */}
                        <button onClick={() => setIsArchiveListOpen(false)} className="px-4 py-2 bg-white border rounded-lg text-sm font-medium hover:bg-slate-100">Schlie{'\u00DF'}en</button>
                    </div>
                </div>
            </div>
        )}

        {/* Edit Modal (Form) */}
        {isModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
            <div className="bg-white w-full max-w-2xl max-h-[90vh] rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
                <div className="p-6 border-b flex items-center justify-between bg-slate-50 shrink-0">
                <div>
                    <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                        {editingItem ? 'Eintrag bearbeiten' : 'Neue Bestellung'}
                        {editingItem && editingItem.ID && (
                            <span className="text-xs font-mono font-normal bg-slate-100 px-2 py-0.5 rounded text-slate-500">{editingItem.ID}</span>
                        )}
                    </h2>
                    <p className="text-sm text-slate-500">Alle Bestelldaten und Wareneingangsinfos</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-500"><X size={20} /></button>
                </div>
                
                <form className="p-6 overflow-y-auto" onSubmit={(e) => {
                    e.preventDefault();
                    const formData = new FormData(e.target);
                    const data = Object.fromEntries(formData.entries());
                        data["Inventarisiert"] = formData.get("Inventarisiert") ? "y" : "";
                        data["Ausgeliefert"] = formData.get("Ausgeliefert") ? "y" : "";
                        data["Ist Projekt"] = formData.get("Ist Projekt") ? "y" : "";
                        if (data["Ist Projekt"] !== "y") data["Projektname"] = "";
                    saveItem(data);
                }}>
                <div className="space-y-8">
                    <div className="relative">
                        <div className="absolute -left-6 top-0 bottom-0 w-1 bg-blue-100"></div>
                        <h3 className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-4 flex items-center gap-2"><Package size={14}/> Bestell-Details</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="md:col-span-2 space-y-1">
                                <label className="text-xs font-semibold text-slate-600 ml-1">Produkt Name <span className="text-red-600">*</span></label>
                                <input name="Produkt" defaultValue={editingItem?.["Produkt"]} required className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm" placeholder="z.B. SOPHOS XGS87" />
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-semibold text-slate-600 ml-1">Hersteller Art.-Nr.</label>
                                <input name="Hersteller Artikelnummer" defaultValue={editingItem?.["Hersteller Artikelnummer"]} className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm" />
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-semibold text-slate-600 ml-1">Datum Bestellung <span className="text-red-600">*</span></label>
                                <input name="Datum Bestellung" type="date" required defaultValue={editingItem?.["Datum Bestellung"] || new Date().toISOString().split('T')[0]} className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm" />
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-semibold text-slate-600 ml-1">Anzahl Bestellt <span className="text-red-600">*</span></label>
                                <input 
                                    name="Anzahl Bestellt" 
                                    type="number" 
                                    required
                                    defaultValue={editingItem?.["Anzahl Bestellt"]} 
                                    onChange={(e) => setCurrentOrderQty(parseInt(e.target.value) || 0)}
                                    className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm" 
                                    />
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-semibold text-slate-600 ml-1">Kunde <span className="text-red-600">*</span></label>
                                <input name="Projekt oder Kunde" required defaultValue={editingItem?.["Projekt oder Kunde"]} className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm" />
                                <div className="flex items-center gap-2 mt-2">
                                    <input 
                                        type="checkbox" 
                                        name="Ist Projekt" 
                                        id="isProj" 
                                        checked={isProjectSelected}
                                        onChange={(e) => setIsProjectSelected(e.target.checked)}
                                        value="y" 
                                        className="rounded text-blue-600 focus:ring-blue-500"
                                    />
                                    <label htmlFor="isProj" className="text-xs text-slate-500 font-medium">Ist ein Projekt?</label>
                                </div>
                            </div>
                            {isProjectSelected && (
                                <div className="space-y-1 animate-in fade-in zoom-in duration-200">
                                    <label className="text-xs font-semibold text-blue-600 ml-1 flex items-center gap-1"><FolderOpen size={12}/> Projektname</label>
                                    <input name="Projektname" defaultValue={editingItem?.["Projektname"]} className="w-full border-blue-200 border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-blue-50" placeholder="z.B. Umbau Halle 3" />
                                </div>
                            )}
                            <div className="space-y-1">
                                <label className="text-xs font-semibold text-slate-600 ml-1">Lieferant <span className="text-red-600">*</span></label>
                                <input name="Lieferant" required defaultValue={editingItem?.["Lieferant"]} className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm" />
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-semibold text-slate-600 ml-1">Bestellt von <span className="text-red-600">*</span></label>
                                <input name="Bestellt von" required defaultValue={editingItem?.["Bestellt von"]} className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm" />
                            </div>
                        </div>
                    </div>

                    <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 relative">
                        <h3 className="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-4 flex items-center gap-2"><CheckCircle2 size={14}/> Wareneingang & Dokumente</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-1">
                                <label className="text-xs font-semibold text-slate-600 ml-1">
                                    Datum Eingang {currentReceiveQty > 0 && <span className="text-red-600">*</span>}
                                </label>
                                <input 
                                    name="Datum Eingang" 
                                    type="date" 
                                    defaultValue={editingItem?.["Datum Eingang"]} 
                                    required={currentReceiveQty > 0}
                                    className="w-full border border-emerald-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500 outline-none text-sm bg-white" 
                                />
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-semibold text-slate-600 ml-1">Anzahl Erhalten</label>
                                <input 
                                    name="Anzahl Erhalten" 
                                    type="number" 
                                    defaultValue={editingItem?.["Anzahl Erhalten"]} 
                                    onChange={(e) => setCurrentReceiveQty(parseInt(e.target.value) || 0)}
                                    className={`w-full border rounded-lg px-3 py-2 outline-none text-sm bg-white ${currentReceiveQty > currentOrderQty ? 'border-red-500 ring-1 ring-red-500 text-red-600' : 'border-emerald-200 focus:ring-2 focus:ring-emerald-500'}`}
                                    placeholder="0" 
                                />
                                {currentReceiveQty > currentOrderQty && (
                                    <div className="text-red-600 text-[10px] font-bold mt-1 flex items-center gap-1 animate-in slide-in-from-top-1">
                                        <AlertTriangle size={10} /> Achtung: Mehr erhalten als bestellt!
                                    </div>
                                )}
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-semibold text-slate-600 ml-1">
                                    Eingebucht von {currentReceiveQty > 0 && <span className="text-red-600">*</span>}
                                </label>
                                <input name="Eingebucht von" defaultValue={editingItem?.["Eingebucht von"]} required={currentReceiveQty > 0} className="w-full border border-emerald-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500 outline-none text-sm bg-white" />
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-semibold text-slate-600 ml-1">Lieferscheinnummer</label>
                                <input name="Lieferscheinnummer" defaultValue={editingItem?.["Lieferscheinnummer"]} className="w-full border border-emerald-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500 outline-none text-sm bg-white" />
                            </div>
                            
                            {/* DATEI UPLOAD BEREICH (VISUAL LIST) */}
                            <div className="md:col-span-2 bg-white p-3 rounded-lg border border-slate-200 mt-2">
                                {/* \u00E4 =   */}
                                <label className="text-xs font-semibold text-slate-600 mb-2 flex items-center gap-1">
                                    <Paperclip size={12}/> Lieferscheine / Dokumente
                                </label>
                                
                                {editingItem && (editingItem.ID || editingItem.ID === undefined) ? (
                                    <div className="space-y-3">
                                        {/* Dateiliste (Mixed: Existing - Deleted + New) */}
                                        {visibleFilesList.length > 0 && (
                                            <ul className="space-y-1 mb-3">
                                                {visibleFilesList.map((file, idx) => (
                                                    <li key={idx} className="flex items-center justify-between text-sm bg-slate-50 p-2 rounded border border-slate-100 group">
                                                        <div className="flex items-center gap-2 truncate">
                                                            <FileText size={14} className={file.isNew ? "text-green-600" : "text-blue-600"}/> 
                                                            {file.isNew ? (
                                                                <span className="text-green-700 italic">{file.name} (Neu)</span>
                                                            ) : (
                                                                <a href={file.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                                                                    {file.name}
                                                                </a>
                                                            )}
                                                        </div>
                                                        <button 
                                                            type="button" 
                                                            onClick={(e) => {
                                                                e.preventDefault();
                                                                e.stopPropagation();
                                                                markFileForDeletion(file.name, file.isNew);
                                                            }}
                                                            className="text-slate-400 hover:text-red-500 p-1 opacity-0 group-hover:opacity-100 transition-opacity" 
                                                            title={"Entfernen"}
                                                        >
                                                            <X size={14}/>
                                                        </button>
                                                    </li>
                                                ))}
                                            </ul>
                                        )}
                                        
                                        {/* Upload Formular (Queue Only) */}
                                        <div className="flex gap-2 items-center">
                                            <input 
                                                type="file" 
                                                multiple 
                                                ref={docInputRef}
                                                onChange={handleFileSelect}
                                                className="block w-full text-xs text-slate-500
                                                    file:mr-2 file:py-2 file:px-4
                                                    file:rounded-full file:border-0
                                                    file:text-xs file:font-semibold
                                                    file:bg-blue-50 file:text-blue-700
                                                    hover:file:bg-blue-100"
                                            />
                                        </div>
                                    </div>
                                ) : (
                                    <div className="text-xs text-slate-400 italic p-2 text-center bg-slate-50 rounded">
                                        Bitte speichern Sie die Bestellung zuerst, um Dokumente hochzuladen.
                                    </div>
                                )}
                            </div>

                            <div className="space-y-1 md:col-span-2">
                                <label className="text-xs font-semibold text-slate-600 ml-1">Seriennummern</label>
                                <textarea name="Seriennummern" defaultValue={editingItem?.["Seriennummern"]} rows="2" className="w-full border border-emerald-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500 outline-none text-sm bg-white" placeholder="S123, S124, ..."></textarea>
                            </div>
                            <div className="flex flex-col gap-2 pt-2 md:col-span-2">
                                <div className="flex items-center gap-2">
                                    <input type="checkbox" name="Inventarisiert" id="inv" defaultChecked={editingItem?.["Inventarisiert"] === 'y'} value="y" className="rounded text-emerald-600 focus:ring-emerald-500"/>
                                    <label htmlFor="inv" className="text-sm font-medium text-slate-700">Inventarisiert?</label>
                                </div>
                                <div className="flex items-center gap-2">
                                    <input type="checkbox" name="Ausgeliefert" id="del" defaultChecked={editingItem?.["Ausgeliefert"] === 'y'} value="y" className="rounded text-blue-600 focus:ring-blue-500"/>
                                    <label htmlFor="del" className="text-sm font-medium text-slate-700">An Kunden ausgeliefert?</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="mt-8 flex gap-3 sticky bottom-0 bg-white pt-4 border-t shrink-0">
                    <button type="submit" disabled={submitting} className="flex-1 bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-100 transition-all flex items-center justify-center gap-2">
                        {submitting ? <Loader2 className="animate-spin"/> : <Save size={18} />} Speichern
                    </button>
                    <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-3 border rounded-xl font-medium hover:bg-slate-50 transition-colors text-slate-600">Abbrechen</button>
                </div>
                </form>
            </div>
            </div>
        )}

        {/* Detail View Modal (Read Only) - MOBILE FIXED LAYOUT */}
        {viewingItem && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
                <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200 flex flex-col max-h-[90vh]">
                    <div className="p-6 border-b flex items-center justify-between bg-slate-50 shrink-0">
                        {/* \u00DF =   */}
                        <h3 className="font-bold text-lg">Details {viewingItem._isArchived && <span className="ml-2 text-xs bg-slate-200 px-2 py-0.5 rounded text-slate-600 font-normal">Archiviert</span>}</h3>
                        {/* FIX: Tooltip als JS Expression f r Umlaute */}
                        <button onClick={() => setViewingItem(null)} className="p-2 hover:bg-slate-200 rounded-full" title={"Schlie\u00DFen"}><X size={20}/></button>
                    </div>
                    <div className="p-6 space-y-6 overflow-y-auto">
                        <div>
                            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-2 flex justify-between">
                                Bestellung
                                <span className="font-mono text-slate-400 font-normal">{viewingItem.ID}</span>
                            </h4>
                            <div className="grid grid-cols-2 gap-y-4 gap-x-2 text-sm">
                                <div><span className="block text-xs text-slate-400">Produkt</span> <span className="font-medium">{viewingItem["Produkt"]}</span></div>
                                <div><span className="block text-xs text-slate-400">Datum</span> <span>{viewingItem["Datum Bestellung"]}</span></div>
                                <div><span className="block text-xs text-slate-400">Hersteller Nr.</span> <span className="font-mono text-xs">{viewingItem["Hersteller Artikelnummer"] || '-'}</span></div>
                                <div><span className="block text-xs text-slate-400">Menge</span> <span>{viewingItem["Anzahl Bestellt"]} Stk.</span></div>
                                <div><span className="block text-xs text-slate-400">Kunde</span> <span>{viewingItem["Projekt oder Kunde"]}</span></div>
                                <div><span className="block text-xs text-slate-400">Ist Projekt?</span> <span>{viewingItem["Ist Projekt"] === 'y' ? 'Ja' : 'Nein'}</span></div>
                                {viewingItem["Ist Projekt"] === 'y' && (
                                    <div className="col-span-2 bg-blue-50 p-2 rounded border border-blue-100">
                                        <span className="block text-xs text-blue-500 font-bold uppercase">Projektname</span> 
                                        <span className="font-medium text-blue-900">{viewingItem["Projektname"] || '-'}</span>
                                    </div>
                                )}
                                <div><span className="block text-xs text-slate-400">Besteller</span> <span>{viewingItem["Bestellt von"]}</span></div>
                                <div><span className="block text-xs text-slate-400">Lieferant</span> <span>{viewingItem["Lieferant"] || '-'}</span></div>
                            </div>
                        </div>
                        <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                            <h4 className="text-xs font-bold text-emerald-600 uppercase tracking-wide mb-2">Eingang</h4>
                            <div className="grid grid-cols-2 gap-y-4 gap-x-2 text-sm">
                                <div><span className="block text-xs text-slate-400">Status</span> 
                                    {(() => {
                                        if(viewingItem._isArchived) return <span className="text-slate-500 font-bold flex items-center gap-1"><Archive size={14}/> Archiviert</span>;
                                        const status = getItemStatus(viewingItem);
                                        if(status === 'completed') return <span className="text-emerald-600 font-bold flex items-center gap-1"><CheckCircle2 size={14}/> Komplett</span>;
                                        if(status === 'partial') return <span className="text-blue-600 font-bold flex items-center gap-1"><PieChart size={14}/> Teillieferung</span>;
                                        {/* \u00DC =  , \u00E4 =   */}
                                        if(status === 'warning') return <span className="text-red-600 font-bold flex items-center gap-1"><AlertTriangle size={14}/> {'\u00DC'}berf{'\u00E4'}llig</span>;
                                        return <span className="text-orange-500 font-bold flex items-center gap-1"><Clock size={14}/> Offen</span>;
                                    })()}
                                </div>
                                <div><span className="block text-xs text-slate-400">Datum Eingang</span> <span>{viewingItem["Datum Eingang"] || '-'}</span></div>
                                <div><span className="block text-xs text-slate-400">Erhalten</span> <span>{viewingItem["Anzahl Erhalten"] || '0'} Stk.</span></div>
                                <div><span className="block text-xs text-slate-400">LS-Nummer</span> <span className="font-mono">{viewingItem["Lieferscheinnummer"] || '-'}</span></div>
                                <div><span className="block text-xs text-slate-400">Eingebucht von</span> <span>{viewingItem["Eingebucht von"] || '-'}</span></div>
                                
                                <div className="col-span-2 flex flex-col gap-2 mt-2 pt-2 border-t border-slate-200">
                                    <div className="flex items-center gap-2">
                                        {viewingItem["Inventarisiert"] === 'y' ? <CheckSquare size={16} className="text-emerald-600"/> : <Square size={16} className="text-slate-300"/>}
                                        <span className="text-xs">Inventarisiert</span>
                                    </div>
                                        <div className="flex items-center gap-2">
                                        {viewingItem["Ausgeliefert"] === 'y' ? <CheckSquare size={16} className="text-blue-600"/> : <Square size={16} className="text-slate-300"/>}
                                        <span className="text-xs">An Kunden ausgeliefert</span>
                                    </div>
                                </div>
                                
                                {/* DOKUMENTE IM DETAIL VIEW (READ ONLY) */}
                                <div className="col-span-2 pt-2 border-t border-slate-200">
                                    {/* \u00E4 =   */}
                                    <span className="block text-xs text-slate-400 mb-1">Angeh{'\u00E4'}ngte Dokumente</span>
                                    {viewingFiles.length > 0 ? (
                                        <ul className="space-y-1">
                                            {viewingFiles.map((file, idx) => (
                                                <li key={idx}>
                                                    <a href={file.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline text-xs flex items-center gap-1">
                                                        <FileText size={12}/> {file.name}
                                                    </a>
                                                </li>
                                            ))}
                                        </ul>
                                    ) : (
                                        <span className="text-xs text-slate-400 italic">- Keine -</span>
                                    )}
                                </div>

                                <div className="col-span-2"><span className="block text-xs text-slate-400 mt-2">Seriennummern</span> <p className="font-mono text-xs bg-white p-2 border rounded mt-1">{viewingItem["Seriennummern"] || '-'}</p></div>
                            </div>
                        </div>
                        {viewingItem._isArchived && (
                            <div className="text-xs text-slate-400 text-center font-mono bg-slate-100 p-2 rounded">
                                Gefunden in: {viewingItem._sourceFile}
                            </div>
                        )}
                    </div>
                    {/* MOBILE HIDDEN FOOTER */}
                    <div className="p-4 bg-slate-50 border-t hidden md:flex justify-end gap-2 shrink-0">
                        {/* FIX: Tooltip als JS Expression f r Umlaute */}
                        <button onClick={() => setViewingItem(null)} className="px-4 py-2 border rounded-lg text-sm bg-white hover:bg-slate-50">Schlie{'\u00DF'}en</button>
                        {/* Edit Button nur anzeigen wenn NICHT archiviert */}
                        {!viewingItem._isArchived && (
                            <button onClick={() => { 
                                const itemToEdit = viewingItem; 
                                setViewingItem(null); 
                                handleOpenModal(itemToEdit);
                            }} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">Bearbeiten</button>
                        )}
                    </div>
                </div>
            </div>
        )}
        </div>
    );
};